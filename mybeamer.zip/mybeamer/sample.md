% 一个Beamer模板的使用
% 程振兴 \ 翻译
% \today

# 导论

## Beamer是什么？

- beamer是一个Latex的类
- 你可以使用\TeX制作一个非常cool的展示

    - 像这样：

### 序言:

```tex
\documentclass[dvipdfmx,default,cjk]{beamer}
```

## 常见的展示工具

- PowerPoint (GUI)
- Keynote (GUI)
- Beamer (Text)

GUI 很难.
写 \TeX 也很难.

因此我们需要寻找一些方便的工具！

## 使用Pandoc

Pandoc - [pandoc.org](http://pandoc.org/)

一个 *文档* $\mapsto$ *文档* 转换工具

- 它支持很多格式的转换！例如：
    1. `.mkd` (markdown)
    1. `.html` `.xml`
    1. `.docx` (Microsoft Words)
    1. `.tex` `.pdf`
    1. and more
- *template* 是用来转换的
    - pandoc 有很多模板供我们选择
    - 你还可以自定义你自己的模板

## 例如

### 从一个`.mkd`文档到 `.tex`文档

Pandoc 对`.tex` 使用通常的 **template**。
格式的输入输出则取决于输入输出文件的拓展名。

```bash
pandoc -o report.tex report.mkd
```

### 从一个`.mkd`文档到 `.tex`幻灯片

指定输出格式为`beamer`即可：

```bash
pandoc -t beamer -o report.tex report.mkd
```

# 方法

## 我编写幻灯片的方法

1. 写一个`.mkd` 文件
2. 使用pandoc将其转变成beamer文件

```bash
pandoc -s -t beamer \
  --template ./themes/pondering.tex \
  -o out.tex in.mkd
```

(另见于 `Makefile`)

3. 把 `platex`文件编译城`.pdf`文件

```bash
platex out
dvipdfmx out
zathura out.pdf
```

# 检查模板

## 枚举与分项

1. 一
1. 二
    - 2
    - 贰
1. 三

- 无序列表
    - 子条目
        - 子子条目
        - 子子条目
- 无序列表
- 无序列表

## 块引用

在md文件中的`###`会产生一个`block`

### 块标题

块内文本

### 块标题

块内文本

## 代码高亮

```bash
seq 1 100 | factor | awk 'NF==2{print $2}'
```

```haskell
main :: IO ()
```

```python
if __name__ == "__main__":
  pass
```

## \TeX 代码嵌入

**BTW**:

Markdown语法非常简单.
如果我们想实现更高级的排版形式，我们需要嵌入使用\TeX.

1. \TeX 可以被嵌入到 `mkd` 文件中
    - `pandoc`会自动识别出来的
1. 所有的行内\TeX会被判别为 \TeX

    - 这就意味着你不能在\TeX中使用`mkd`

## 例子——分列

Markdown中没有关于分列的语法.
这个模板为分列设置了特别的语法(\TeX 宏).

\BeginColumn{.4}

```tex
\BeginColumn{.6}
  Left column
\Column
  Right column
\EndColumn{.4}
```

\Column{.1}

generates

\Column{.5}

```tex
\begin{columns}
  \column{.6\textwidth}
    Left column
  \column{.4\textwidth}
    Right column
\end{columns}
```

\EndColumn
